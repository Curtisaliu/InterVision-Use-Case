import boto3
import json
from decimal import Decimal

# Helper class to convert DynamoDB items to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):
    # Initialize a DynamoDB client
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('PrescriptionsTable')
    
    # Check if the slot for prescription number was provided
    if 'currentIntent' in event:
        slots = event['currentIntent']['slots']
        prescription_number = slots.get('PrescriptionNumber', None)
        
        if not prescription_number:
            # Elicit the slot for prescription number
            return {
                'dialogAction': {
                    'type': 'ElicitSlot',
                    'intentName': event['currentIntent']['name'],
                    'slots': slots,
                    'slotToElicit': 'PrescriptionNumber',
                    'message': {
                        'contentType': 'PlainText',
                        'content': 'Please state your prescription number to proceed.'
                    }
                }
            }
    
        try:
            # Get the item from DynamoDB using the provided prescription number
            response = table.get_item(Key={'PrescriptionNumber': prescription_number})
            
            # Check if the item exists
            if 'Item' in response:
                # Return the details of the prescription
                return {
                    'dialogAction': {
                        'type': 'Close',
                        'fulfillmentState': 'Fulfilled',
                        'message': {
                            'contentType': 'PlainText',
                            'content': json.dumps(response['Item'], cls=DecimalEncoder)
                        }
                    }
                }
            else:
                # Return a message saying the prescription was not found
                return {
                    'dialogAction': {
                        'type': 'Close',
                        'fulfillmentState': 'Failed',
                        'message': {
                            'contentType': 'PlainText',
                            'content': 'The prescription number provided was not found.'
                        }
                    }
                }
        except Exception as e:
            print(e)
            # Handle any other exceptions by closing the dialog
            return {
                'dialogAction': {
                    'type': 'Close',
                    'fulfillmentState': 'Failed',
                    'message': {
                        'contentType': 'PlainText',
                        'content': 'An error occurred while retrieving prescription information.'
                    }
                }
            }
    else:
        # If the required data isn't in the event, close the dialog
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Failed',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'There was a problem processing your request.'
                }
            }
        }
