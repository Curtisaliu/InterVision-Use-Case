import boto3
import json

# Initialize a DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('AppointmentsTable')

def lambda_handler(event, context):
    # Extract 'AppointmentID' and 'UserID' from the event
    appointment_id = event.get('AppointmentID')
    user_id = event.get('UserID')

    # Attempt to delete the appointment record
    try:
        response = table.delete_item(
            Key={
                'AppointmentID': appointment_id,
                'UserID': user_id
            },
            ReturnValues='ALL_OLD'
        )
        
        # Check if the item was deleted
        if 'Attributes' in response:
            return {
                'statusCode': 200,
                'message': 'Appointment cancelled successfully.'
            }
        else:
            return {
                'statusCode': 400,
                'message': 'Appointment not found.'
            }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'message': 'Error cancelling appointment.'
        }
