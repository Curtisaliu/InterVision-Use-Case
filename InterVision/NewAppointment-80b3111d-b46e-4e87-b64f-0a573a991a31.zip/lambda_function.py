import boto3
import json
import random
import string

def generate_appointment_id():
    # Generate a random string with 4 letters followed by 5 digits
    letters = ''.join(random.choice(string.ascii_uppercase) for _ in range(4))
    digits = ''.join(random.choice(string.digits) for _ in range(5))
    return letters + digits

def lambda_handler(event, context):
    # Initialize a DynamoDB client
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('AppointmentsTable')
    
    # Extract details from the event
    user_id = event['UserID']
    appointment_date = event['AppointmentDate']
    time = event['Time']
    vaccine_type = event['VaccineType']
    
    # Generate a unique AppointmentID with the specified format
    appointment_id = generate_appointment_id()
    
    # Prepare the item to be put in the DynamoDB table
    item = {
        'AppointmentID': appointment_id,
        'UserID': user_id,
        'AppointmentDate': appointment_date,
        'Time': time,
        'VaccineType': vaccine_type,
        'Location': 'Downtown Health Center',
        'AppointmentStatus': 'Scheduled'  # Assuming the status should be 'Scheduled' by default
    }
    
    try:
        # Put the new item into the DynamoDB table
        table.put_item(Item=item)
        return {
            'statusCode': 200,
            'body': json.dumps({
                'AppointmentID': appointment_id,
                'message': 'Appointment successfully scheduled.'
            })
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error scheduling the appointment.'
            })
        }
