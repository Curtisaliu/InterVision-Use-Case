import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime

def format_time(iso_time_str):
    # Parse the ISO formatted time and convert it to a 12-hour format with AM/PM
    # Adjusted to correctly parse the 'T' in the ISO string and handle 'Z' as UTC timezone indicator
    time_obj = datetime.strptime(iso_time_str, "T%H:%M:%SZ")
    return time_obj.strftime("%I:%M%p").lstrip("0").replace("AM", "AM").replace("PM", "PM")

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('AppointmentsTable')
    
    appointment_id = event.get('Details', {}).get('Parameters', {}).get('AppointmentID')
    user_id = event.get('Details', {}).get('Parameters', {}).get('UserID')
    
    try:
        if user_id:
            response = table.query(
                IndexName='UserID-index',
                KeyConditionExpression=Key('UserID').eq(user_id)
            )
            items = response.get('Items', [])
        elif appointment_id:
            response = table.get_item(Key={'AppointmentID': appointment_id})
            items = [response.get('Item')] if 'Item' in response else []
        else:
            return {'statusCode': 400, 'error': 'Neither UserID nor AppointmentID was provided'}

        if items:
            # For querying by UserID, we assume the latest appointment is desired.
            # For querying by AppointmentID, there should only be one item.
            latest_appointment = max(items, key=lambda x: x['AppointmentDate']) if user_id else items[0]
            formatted_time = format_time(latest_appointment.get('Time', '00:00:00Z'))
            result = {
                'AppointmentID': latest_appointment.get('AppointmentID'), # Include AppointmentID in the result
                'UserID': latest_appointment.get('UserID', user_id), # Include UserID in the result, default to provided UserID if not present
                'AppointmentDate': latest_appointment['AppointmentDate'],
                'Time': formatted_time,
                'AppointmentStatus': latest_appointment['AppointmentStatus'],
                'Location': latest_appointment['Location'],
                'VaccineType': latest_appointment['VaccineType'],
                'statusCode': 200
            }
            # If the UserID is not part of the original record (for queries by AppointmentID), fetch it.
            if 'UserID' not in latest_appointment and appointment_id:
                user_info = table.get_item(Key={'AppointmentID': appointment_id}).get('Item', {})
                result['UserID'] = user_info.get('UserID', 'Unknown') # Fallback to 'Unknown' if UserID is not found
            return result
        else:
            return {'statusCode': 400, 'error': 'No appointment found for the provided identifier'}
    except Exception as e:
        return {'statusCode': 500, 'error': 'Error retrieving appointment information', 'details': str(e)}
