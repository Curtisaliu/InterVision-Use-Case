import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime

# Initialize a DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('AppointmentsTable')

def is_iso8601(time_str):
    try:
        datetime.strptime(time_str, 'T%H:%M:%SZ')
        return True
    except (ValueError, TypeError):
        return False

def convert_to_iso8601(time_str):
    try:
        time_obj = datetime.strptime(time_str, '%H:%M')
        return time_obj.strftime('T%H:%M:00Z')
    except (ValueError, TypeError) as e:
        print(f"Error converting to ISO 8601: {e}")
        return None

def format_time_for_response(iso_time_str):
    try:
        time_obj = datetime.strptime(iso_time_str, 'T%H:%M:%SZ')
        return time_obj.strftime('%I:%M %p').lstrip('0').replace('AM', 'AM').replace('PM', 'PM')
    except (ValueError, TypeError) as e:
        print(f"Error formatting time for response: {e}")
        return iso_time_str

def lambda_handler(event, context):
    print("Received event:", event)
    
    details = event.get('Details', {})
    params = details.get('Parameters', {})
    user_id = params.get('UserID')
    new_appointment_date = params.get('AppointmentDate')
    new_time = params.get('Time')
    new_vaccine_type = params.get('VaccineType')

    if new_time and not is_iso8601(new_time):
        iso_time = convert_to_iso8601(new_time)
    else:
        iso_time = new_time
    if not iso_time:
        return {
            'statusCode': 400,
            'message': 'Invalid or missing time format. Please provide time in "HH:MM" or ISO 8601 format.'
        }

    try:
        response = table.query(
            IndexName='UserID-index',
            KeyConditionExpression=Key('UserID').eq(user_id)
        )

        if response['Count'] == 0:
            return {
                'statusCode': 400,
                'message': 'No appointment found for the provided UserID.'
            }

        appointment_to_update = response['Items'][0]['AppointmentID']
        existing_vaccine_type = response['Items'][0].get('VaccineType')

        update_expression = 'SET AppointmentDate = :date, #t = :time'
        expression_attribute_values = {
            ':date': new_appointment_date,
            ':time': iso_time
        }
        
        if new_vaccine_type:  # Only update VaccineType if provided
            update_expression += ', VaccineType = :vaccine'
            expression_attribute_values[':vaccine'] = new_vaccine_type
        else:
            new_vaccine_type = existing_vaccine_type  # Use existing if not provided

        update_response = table.update_item(
            Key={
                'AppointmentID': appointment_to_update,
                'UserID': user_id
            },
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames={
                "#t": "Time"
            },
            ReturnValues='UPDATED_NEW'
        )

        return {
            'statusCode': 200,
            'AppointmentDate': new_appointment_date,
            'Time': format_time_for_response(iso_time),
            'VaccineType': new_vaccine_type  # Return the updated or existing vaccine type
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'message': 'Error updating appointment information',
            'error_details': str(e)
        }
