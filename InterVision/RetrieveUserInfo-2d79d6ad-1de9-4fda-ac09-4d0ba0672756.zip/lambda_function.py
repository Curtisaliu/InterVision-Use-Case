import boto3
import json

def lambda_handler(event, context):
    # Initialize a DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('UserTable')
    
    # Using .get() to safely access nested dictionaries
    user_id = event.get('Details', {}).get('Parameters', {}).get('UserID')

    if not user_id:
        # Return a helpful message if UserID isn't provided
        return {
            'statusCode': 400,
            'UserNotFound': 'True',
            'ErrorMessage': 'UserID not provided'
        }
    
    try:
        response = table.get_item(Key={'UserID': user_id})
        if 'Item' in response:
            # User information found, return key-value pairs
            user_info = response['Item']
            user_info['statusCode'] = 200
            return user_info
        else:
            # User information not found
            return {
                'statusCode': 404,
                'UserNotFound': 'True',
                'ErrorMessage': 'User not found'
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'Error': 'True',
            'ErrorMessage': 'Error retrieving user information: ' + str(e)
        }
