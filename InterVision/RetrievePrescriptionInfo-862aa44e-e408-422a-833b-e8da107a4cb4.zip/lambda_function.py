import boto3
import json
from decimal import Decimal
from datetime import datetime, timedelta

# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    # Initialize a DynamoDB client
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('PrescriptionsTable')

    # Extract 'PrescriptionID' from the event object sent by Amazon Connect
    prescription_id = event.get('Details', {}).get('Parameters', {}).get('PrescriptionID')

    if not prescription_id:
        # If PrescriptionID is not provided, return an error message
        return {
            'error': 'PrescriptionID not provided',
            'statusCode': 400
        }

    try:
        # Attempt to retrieve the prescription from the DynamoDB table
        response = table.get_item(Key={'PrescriptionID': prescription_id})
        if 'Item' in response:
            # Prepare the DynamoDB item for JSON serialization
            item = response['Item']
            # Convert the LastRefillDate from string to date
            last_refill_date = datetime.strptime(item['LastRefillDate'], '%Y-%m-%d')
            # Determine if it's time for a refill based on the last refill date
            refill_due = datetime.now() - last_refill_date >= timedelta(days=30)  # assuming a 30-day refill cycle
            # Add the refill_due status to the item
            item['RefillDue'] = refill_due
            # Add the statusCode 200 for success
            item['statusCode'] = 200
            # Return the item directly without a 'body' wrapper
            return json.loads(json.dumps(item, cls=DecimalEncoder))
        else:
            # The prescription was not found in the table
            return {
                'error': 'Prescription not found',
                'statusCode': 404
            }
    except Exception as e:
        # Log the error and return an error message
        print(e)
        return {
            'error': 'Error retrieving prescription information',
            'statusCode': 500
        }
